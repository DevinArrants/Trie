1) Devin Arrants devin.g.arrants@vanderbilt.edu
2) I estimate this will take 14 hours.
3) I only spent 8 hours on the assignment.
4) I did not access any other material other than the ever helpful TAs.
5) I enjoy this type of data structure. At first I was really overwelmed,
but once reading the spec over a few times, it was easy. There was nothing I did 
not like.
6) The project description was very thorough and especially helpful this project. 
